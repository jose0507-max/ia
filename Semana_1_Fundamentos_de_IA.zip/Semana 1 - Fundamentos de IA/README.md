# Semana 1 - Fundamentos de IA

Evidencia de la Semana 1 del curso de Inteligencia Artificial.
**Autor:** José Londoño

## Contenido

| Entregable | Archivo | Descripción |
|---|---|---|
| Mapa conceptual | [`mapa_conceptual/mapa_conceptual_ia.png`](mapa_conceptual/mapa_conceptual_ia.png) | Explica qué son la IA, el Machine Learning, el Deep Learning y la IA generativa, cómo se relacionan entre sí y ejemplos cotidianos de cada uno. |
| Caso de uso | [`caso_de_uso/caso_de_uso.md`](caso_de_uso/caso_de_uso.md) | Propuesta de *RutaEstudio*, un sistema que recomienda materiales de estudio a estudiantes universitarios, con problema, objetivo, usuarios, funcionamiento, tecnologías de IA, resultados esperados, alcance y limitaciones. |

## Estructura

```
Semana 1 - Fundamentos de IA/
├── mapa_conceptual/
│   └── mapa_conceptual_ia.png
├── caso_de_uso/
│   └── caso_de_uso.md
└── README.md
```

## Nota

El caso de uso es una **propuesta**: el sistema no está implementado y no se presentan resultados reales.
