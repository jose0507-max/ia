# Caso de uso: recomendador de materiales de estudio

> **Estado:** esta es una **propuesta** hecha como ejercicio de la Semana 1. El sistema **no está implementado** y no se presentan resultados reales, solo lo que se espera lograr.

## 1. Nombre del proyecto

**RutaEstudio**: un sistema que recomienda materiales de estudio a estudiantes universitarios.

## 2. Problema que busca solucionar

Un estudiante universitario suele encontrar muchísimo material para estudiar: libros, videos, artículos, guías y ejercicios. Tener tanta información puede ser un problema, porque:

- No siempre sabe cuál material es el más adecuado para su nivel.
- Pierde tiempo buscando en varios sitios.
- A veces estudia con materiales muy difíciles o muy básicos para lo que necesita en ese momento.

## 3. Objetivo

**Objetivo general:** proponer un sistema que sugiera a cada estudiante materiales de estudio útiles para sus materias, su nivel y sus necesidades.

**Objetivos específicos:**

- Ayudar a que el estudiante encuentre materiales relevantes más rápido.
- Sugerir materiales según lo que ya estudió y lo que le cuesta más.
- Ofrecer explicaciones y ejercicios sencillos como apoyo al estudio.

## 4. Usuarios

- **Estudiantes universitarios** (usuarios principales): reciben las recomendaciones.
- **Profesores** (usuarios de apoyo): pueden subir o sugerir materiales confiables para sus cursos.

## 5. Información que necesita recibir

Antes de hablar de cómo funciona, conviene definir qué son los **datos**: la información que el sistema usa para tomar decisiones. En este caso serían:

| Tipo de dato | Ejemplo |
|---|---|
| Perfil del estudiante | Carrera, semestre y materias que cursa |
| Tema que quiere estudiar | "Derivadas", "Ciclos en programación" |
| Nivel o dificultad percibida | Básico, intermedio o avanzado |
| Historial de uso | Materiales que ya consultó y si le sirvieron (por ejemplo, una calificación de 1 a 5) |
| Catálogo de materiales | Título, tema, nivel, formato (video, texto, ejercicios) |

**Nota:** se pediría solo lo necesario y con permiso del estudiante, porque esta información es personal.

## 6. Cómo funcionaría

El funcionamiento propuesto sería un proceso en cinco pasos:

1. **El estudiante indica** su materia, el tema y su nivel.
2. **El sistema filtra** el catálogo y deja solo los materiales de ese tema y nivel.
3. **El sistema ordena** esos materiales según lo que le sirvió a estudiantes con necesidades parecidas.
4. **El estudiante recibe** una lista corta de recomendaciones (por ejemplo, tres materiales).
5. **El estudiante califica** si el material le fue útil, y esa respuesta se guarda para mejorar las próximas recomendaciones.

Como apoyo adicional, el sistema podría generar un breve resumen o preguntas de práctica a partir de un material elegido.

## 7. Tecnologías de IA que podría utilizar

Primero, un repaso corto de cada concepto:

- **Inteligencia artificial (IA):** computadores que realizan tareas que normalmente requieren inteligencia humana, como decidir o recomendar.
- **Machine Learning (aprendizaje automático):** una parte de la IA en la que el sistema aprende a partir de ejemplos, en lugar de seguir solo reglas escritas por una persona.
- **IA generativa:** una parte de la IA que crea contenido nuevo, como textos, explicaciones o preguntas.

| Concepto | Cómo se aplicaría en RutaEstudio | Ejemplo |
|---|---|---|
| **IA con reglas simples** | Filtros que descartan materiales que no corresponden a la materia, el tema o el nivel. | Si el estudiante pide "derivadas, nivel básico", se excluyen los materiales avanzados. |
| **Machine Learning** | Aprender de las calificaciones y del historial para sugerir materiales que les sirvieron a estudiantes parecidos. | Es parecido a cuando una plataforma de series recomienda según lo que otros usuarios con gustos similares vieron. |
| **IA generativa** | Crear resúmenes sencillos o preguntas de práctica a partir de un material. | Dado un texto sobre ciclos en programación, generar cinco preguntas para repasar. |

Se buscaría mantener la propuesta simple: **no se necesitan tecnologías complejas** para una primera versión. Las reglas de filtrado y un método básico de recomendación serían suficientes para empezar, y la IA generativa se agregaría como complemento opcional.

## 8. Resultados esperados

Estos son resultados que se **esperan** lograr si el sistema se llegara a construir, y tendrían que comprobarse con pruebas reales:

- Que los estudiantes encuentren materiales adecuados en menos tiempo.
- Que las recomendaciones sean consideradas útiles por los estudiantes (se medirían con sus calificaciones).
- Que los resúmenes y preguntas de práctica sirvan como apoyo para repasar.

No se puede afirmar todavía cuánto mejoraría el estudio, porque eso solo se sabría después de probar el sistema con estudiantes.

## 9. Alcance y limitaciones

### Alcance (lo que sí incluye la propuesta)

- Una primera versión pensada para **una universidad** y **pocas materias** (por ejemplo, dos o tres cursos de prueba).
- Recomendaciones de materiales en **español**.
- Un catálogo de materiales revisados por profesores.
- Resúmenes y preguntas de práctica como función complementaria.

### Limitaciones (lo que no hace o puede fallar)

- **Pocos datos al inicio:** un estudiante nuevo no tiene historial, así que las primeras recomendaciones serían menos precisas y se apoyarían más en las reglas simples.
- **Calidad de los materiales:** si el catálogo tiene materiales malos, las recomendaciones también lo serán.
- **Errores de la IA generativa:** puede escribir información incorrecta o poco clara, por lo que sus resúmenes y preguntas deberían ser revisados por el estudiante o el profesor.
- **Privacidad:** se manejarían datos personales, por lo que se necesitaría pedir permiso y protegerlos.
- **No reemplaza al profesor:** el sistema es una ayuda para estudiar, no sustituye la enseñanza ni la evaluación.
- **Propuesta sin implementar:** todo lo descrito es un plan inicial y podría cambiar al construirlo.
